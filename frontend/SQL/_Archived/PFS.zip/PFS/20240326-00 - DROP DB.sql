EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'PFSProcess'
GO

USE [master]
GO
/****** Object:  Database [PFSProcess]    Script Date: 3/26/2024 6:49:15 PM ******/
DROP DATABASE [PFSProcess]
GO
